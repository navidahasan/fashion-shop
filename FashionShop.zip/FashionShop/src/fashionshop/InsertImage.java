package fashionshop;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class InsertImage
 */
@WebServlet("/admin/InsertImage")
@MultipartConfig(maxFileSize = 16177215) 
public class InsertImage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertImage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		try {
			
			Part filePart = request.getPart("file");	
			int cat = Integer.parseInt(request.getParameter("cat"));
			int subcat = Integer.parseInt(request.getParameter("subcat"));
			String name = request.getParameter("name");
			int price = Integer.parseInt(request.getParameter("price"));
			String desc = request.getParameter("description");


			
			InputStream inputStream = filePart.getInputStream();			
			
			Connection con = Database.getConnection();
			PreparedStatement ps=con.prepareStatement("INSERT INTO items(category,subcategory,name,price,image,description)"
					+ "VALUES(?,?,?,?,?,?)");
			
			ps.setInt(1, cat);
			ps.setInt(2, subcat);
			ps.setString(3, name);
			ps.setInt(4, price);
			ps.setBlob(5, inputStream);
			ps.setString(6, desc);

			
			
			ps.execute();
			request.setAttribute("msg", "success!");
		}catch (Exception e) {
			// TODO: handle exception
			request.setAttribute("msg", "failed!");
		}
		RequestDispatcher rd = request.getRequestDispatcher("additem.jsp");
		rd.forward(request, response);
	}

}
